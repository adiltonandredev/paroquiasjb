var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/masses/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__5f08ce71._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_masses_[id]_route_actions_6a58c352.js")
R.m(26576)
module.exports=R.m(26576).exports
