var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/masses/route.js")
R.c("server/chunks/[root-of-the-server]__185d2cbd._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_masses_route_actions_5818762c.js")
R.m(9737)
module.exports=R.m(9737).exports
