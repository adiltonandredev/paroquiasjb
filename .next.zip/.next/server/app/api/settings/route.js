var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/settings/route.js")
R.c("server/chunks/[root-of-the-server]__cc138c67._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_settings_route_actions_a476013b.js")
R.m(61525)
module.exports=R.m(61525).exports
