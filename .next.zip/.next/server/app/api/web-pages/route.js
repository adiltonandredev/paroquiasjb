var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/web-pages/route.js")
R.c("server/chunks/[root-of-the-server]__a070f423._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_web-pages_route_actions_e4a7eb8a.js")
R.m(71414)
module.exports=R.m(71414).exports
